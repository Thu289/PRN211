﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRN211_SE
{
    internal class Ex1_1
    {
        public static void Mains() 
        {
            Console.WriteLine("Ngon ngu lap trinh C# - C Sharp");
        }
    }
}
