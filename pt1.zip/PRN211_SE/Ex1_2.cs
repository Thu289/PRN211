﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRN211_SE
{
    internal class Ex1_2
    {
        public static void Mains()
        {
            int n = 100;
            Console.WriteLine($"n = {n}");
            n += 200;
            Console.WriteLine($"n = {n}");
        }
    }
}
