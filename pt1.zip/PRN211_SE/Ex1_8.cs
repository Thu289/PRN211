﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace PRN211_SE
{
    internal class Ex1_8
    {
        public static void Main()
        {
            Console.WriteLine("{0,10} sdfgg", "-");
            for (int i=0; i<50; i++)
            {
                Console.Write("-");
            }


        }
    }
}